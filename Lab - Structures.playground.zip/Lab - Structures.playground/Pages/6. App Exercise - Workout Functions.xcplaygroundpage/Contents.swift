/*:
## App Exercise - Workout Functions
 
 >These exercises reinforce Swift concepts in the context of a fitness tracking app.
 
 A `RunningWorkout` struct has been created for you below. Add a method on `RunningWorkout` called `postWorkoutStats` that prints out the details of the run. Then create an instance of `RunningWorkout` and call `postWorkoutStats()`.
 */
struct RunningWorkout {
    var distance: Double   // in meters
    var time: Double       // in minutes
    var elevation: Double  // in meters

    func postWorkoutStats() {
        print("Distance: \(distance) meters")
        print("Time: \(time) minutes")
        print("Elevation Gain: \(elevation) meters")
    }
}
let workout = RunningWorkout(distance: 5000, time: 30, elevation: 100)
workout.postWorkoutStats()




//:  A `Steps` struct has been created for you below, representing the day's step-tracking data. It has the goal number of steps for the day and the number of steps taken so far. Create a method on `Steps` called `takeStep` that increments the value of `steps` by one. Then create an instance of `Steps` and call `takeStep()`. Print the value of the instance's `steps` property before and after the method call.
struct Steps {
    var goal: Int
    var steps: Int

    mutating func takeStep() {
        steps += 1
    }
}
var todaySteps = Steps(goal: 10000, steps: 9995)
print("Steps before: \(todaySteps.steps)")
todaySteps.takeStep()
print("Steps after: \(todaySteps.steps)")


/*:
[Previous](@previous)  |  page 6 of 10  |  [Next: Exercise - Computed Properties and Property Observers](@next)
 */
